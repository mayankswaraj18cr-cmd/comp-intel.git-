# CompIntel — Compensation Intelligence System

**Role:** Frontend Engineer · **Track:** B — Compensation Intelligence System

A compensation comparison platform built around the brief's core principle:
**levels matter more than job titles.** See [`RESEARCH.md`](./RESEARCH.md) for the
mandatory pre-implementation research and feature comparison sheet.

## Quick start

```bash
npm install
npm run dev
# → http://localhost:3000
```

```bash
npm run build && npm run start   # production build
npm run lint                     # ESLint (0 errors)
npx tsc --noEmit                 # TypeScript check (0 errors)
```

No environment variables or database needed — the dataset is generated
in-memory with a fixed seed (see "Data layer" below), so the app runs
immediately with no setup.

## The 4 features (chosen deliberately, not all 5+ shallowly)

Per the brief's own evaluation priority ("clean architecture, reliable systems,
extensibility... [over] excessive features"):

1. **Compensation Explorer** (`/`) — searchable, filterable (company / role /
   level band / location), sortable (YOE / base / total comp, both directions),
   paginated table. Filter state is synced to the URL so results are
   shareable/bookmarkable.
2. **Company pages** (`/companies`, `/companies/[slug]`) — browsable company
   cards, then a detail page with aggregate stats, a level-by-level average
   compensation chart, and the full underlying report table.
3. **Compare tool** (`/compare`) — select 2–3 companies, see average total
   comp charted side-by-side plus a full metric-by-metric comparison table
   including per-level-band averages.
4. **Data normalization layer** — not a page, but the thing every reference
   platform except Levels.fyi visibly gets wrong (see `RESEARCH.md`):
   canonical company names, default-to-zero for missing bonus/stock,
   level-band standardization independent of company-specific title strings.

## Architecture

```
src/
  types/compensation.ts       Domain types — CompensationEntry, CompanyAggregate,
                                CompensationFilters. LevelBand is separate from
                                levelLabel by design (see "Levels vs titles" below).
  lib/
    data.ts                    Mock dataset generation + company-name normalization
                                + aggregation (getAllEntries, getCompanyAggregates)
    query.ts                    Filtering/sorting/pagination logic + searchParam parsing
    format.ts                   Shared display formatters (₹XX.XL, level badge colors)
  components/
    CompensationExplorer.tsx    Client component: filter bar + sortable table + pagination
    CompareBuilder.tsx           Client component: company multi-select + comparison view
    CompanyCard.tsx               Server-renderable presentational card
    BarChart.tsx                  Dependency-free SVG bar chart
  app/
    page.tsx                      Explorer (home)
    companies/page.tsx             Company listing
    companies/[slug]/page.tsx       Company detail (Server Component)
    companies/[slug]/not-found.tsx  404 for unknown company slugs
    compare/page.tsx                Compare tool
    api/
      compensation/route.ts         GET — filtered/sorted/paginated entries
      companies/route.ts             GET — company aggregates (+ search)
      companies/[slug]/route.ts       GET — single company detail
      compare/route.ts                GET — 2-3 company comparison, validates count
```

Data flows one direction: `lib/data.ts` (source of truth) → API routes (thin,
just call `lib/query.ts` / `lib/data.ts` and return JSON) → client components
fetch from the API routes, exactly as they would against a real backend. This
means swapping the in-memory dataset for a real Postgres/Prisma-backed API
later requires no changes to any component — only `lib/data.ts` changes.

## Technical decisions

**Why levels, not titles, as the primary comparison key.** Job titles don't
mean the same thing across companies ("Senior Engineer" spans a huge comp
range depending on employer), which is exactly the failure mode Glassdoor and
AmbitionBox have (see `RESEARCH.md`). `CompensationEntry` carries both a
company-specific `levelLabel` (e.g. "L5", "SDE-3", "E5" — what a user
recognizes) and a standardized `levelBand` (Entry/Mid/Senior/Staff/Principal —
what the comparison logic actually groups and averages on). Every
cross-company aggregate (`CompanyAggregate.levelBreakdown`) is keyed on
`levelBand`, not `levelLabel`.

**Why a generated, seeded mock dataset instead of scraped data.** Scraping
Levels.fyi/AmbitionBox/Glassdoor directly would raise both data-rights and
reliability concerns for a submission meant to be run and reviewed by someone
else. Instead, `lib/data.ts` generates ~280 entries across 18 real companies
using a seeded PRNG (`mulberry32`, seed `20260820`) — deterministic, so the
dataset (and therefore every filter/sort/comparison result) is identical on
every run, which matters for demoing/reviewing without numbers shifting
under you. The generator deliberately introduces realistic messiness (not
every company has every level; ~15% of entries omit bonus or stock; company
names are drawn from a pool of raw aliases) so the normalization layer has
real problems to solve rather than clean input.

**Why company-name normalization lives in the data layer, not components.**
`normalizeCompanyName()` runs once, at generation time, mapping messy raw
input ("Google India", "google llc", "Alphabet") to one canonical
`{ slug, name }`. This means every component downstream — table, cards,
compare tool — works with already-clean data and never re-implements
matching logic. Unrecognized companies aren't dropped; they get a slugified
fallback so the entry is still visible rather than silently disappearing (the
brief's "reject invalid data" principle is about malformed data, not
unfamiliar-but-valid data).

**Why bonus/stock default to 0 rather than being omitted.**
`CompensationEntry.totalCompLpa` is always `base + bonus + stock` computed at
generation time — never left for a component to (re-)derive, which would risk
inconsistent totals if two components computed it slightly differently. When
a report doesn't include bonus/stock, the field is explicitly `0`, not
`undefined` — this was the brief's explicit instruction, and it also keeps
every arithmetic/sort operation type-safe (`number`, not `number | undefined`)
throughout the query layer.

**Why a hand-rolled SVG bar chart instead of a charting library.** The
visualizations here are simple, small-N bar comparisons (comp-by-level,
comp-by-company) — pulling in Recharts/Chart.js for that is a meaningfully
larger dependency for a marginal gain. `BarChart.tsx` is ~60 lines, fully
typed, and predictable. Tradeoff acknowledged: this would not scale to a
larger visualization set (stacked/grouped bars, tooltips, animation) without
real effort, so if the platform grows past 2 chart types, adopting a library
becomes the right call. This is called out here explicitly as a scoped
tradeoff, not an oversight.

**Why filters live in component state + URL, not global state (Redux/Zustand
etc.).** With one page actually needing complex filter state
(`CompensationExplorer`), a global store adds indirection without benefit.
Filter state syncs to the URL via `router.replace` (no full navigation) so
results are shareable — this is the one piece of "global" behavior that
matters here, and it doesn't need a state management library to achieve.

**Server vs. Client Components.** Static/listing pages (`/companies`, company
detail) are Server Components — they read `lib/data.ts` directly at render
time, no client-side fetch waterfall, no loading spinner needed for content
that doesn't change per-interaction. Only pages with real interactivity
(filtering, sorting, multi-select) are Client Components. This is a real
architectural decision — early in development, `BarChart` was being handed a
formatter *function* as a prop from a Server Component, which React
correctly rejects (functions aren't serializable across the server/client
boundary); fixed by changing the prop to a serializable `format: "lpa" |
"raw"` string flag instead of a callback. Caught by testing the production
build, not just the dev server.

## Edge cases handled

- **Empty filter results** — explorer shows a clear "No results match these
  filters" message instead of a blank table.
- **Unknown company slug** — `/companies/[slug]` calls `notFound()` → renders
  a proper 404 page; the API route returns `404` with an error body rather
  than a generic 500.
- **Compare with <2 or >3 companies** — `/api/compare` validates count
  server-side (`400` with a descriptive error) rather than trusting the
  client; the UI also disables further selection past 3 and shows a prompt
  at exactly 1 selected.
- **Malformed numeric query params** (e.g. `?minComp=abc`) —
  `parseFiltersFromSearchParams` uses `Number.isFinite` and falls back to
  `undefined` rather than propagating `NaN` into filter comparisons.
- **Missing bonus/stock** — defaulted to `0` at generation time (see above),
  displayed as "—" in tables rather than "₹0.0L" to distinguish "not
  reported" from "reported as zero" visually, without it being a distinct
  code path.
- **Deselecting companies mid-comparison** — dropping below 2 selected
  companies clears the stale comparison result immediately (handled in the
  selection handler, not via a delayed effect) so the UI never shows a
  comparison for companies no longer selected.

## Known limitations / what I'd build next

- **No persistence** — dataset is regenerated in-memory on server restart.
  Swapping in Postgres + Prisma (per the brief's suggested stack) would only
  require rewriting `lib/data.ts`'s internals; the API route and component
  layer are already shaped as if talking to a real backend.
- **No authentication** — out of scope per `RESEARCH.md`; not required for
  the Frontend Engineer + Track B combination and would dilute focus on the
  comparison/normalization work actually being evaluated.
- **Chart library** — see the BarChart tradeoff above; would revisit if the
  visualization surface grows.
- **No pagination on `/companies`** — 18 companies renders fine in a single
  grid; would add pagination or virtualization well before this became a
  problem at real scale, using the same pattern already built for
  `/api/compensation`.
